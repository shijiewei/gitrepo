/**
 *<p> Title: GetMobile.java</br>
 *<p>Description: TODO(describe the file) </br>
 * @Copyright: Copyright (c) 2015
 * @author lijn
 * @version 2018年9月5日
 */
package com.zzx.ctc.getmobile;

import java.security.PublicKey;
import java.util.TreeMap;

import javax.crypto.Cipher;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.zzx.util.AESUtils;
import com.zzx.util.Base64;
import com.zzx.util.HttpClientUtil;
import com.zzx.util.MD5;
import com.zzx.util.RSAHelper;
import com.zzx.util.Uuid16;


/**
 * <p>Title: GetMobile</br>
 * <p>Description: TODO(电信取号) </br>
 * @author lijn
 * @version 
 */
public class GetMobile {
	private static final Logger logger = Logger.getLogger(GetMobile.class);
	//公钥
	private static String pubKey = "";
	
	public static void main(String[] args) {
		tokenValidate("accessCode");
	}
	
	public  static String tokenValidate(String accessCode) {
		System.out.println("【tokenValidate】");
		try {
			String url = "http://127.0.0.1";
			String apiTemp = "/api/netm/v1.0/gmctc";
			
			url = url + apiTemp;
			// 填写参数
			String apiKey = "";// 鉴权密钥
			String n = "";// 应用名称
			String c = "";// 版本号
			String v = "";// 版本名称
			String pk = "";// 应用包名
			String ot = "";// 运营商标识(选填)
			String md5 = "";//android 填写MD5信息
			
			// 参数处理
			String paramsKey = "";// 参数密钥，随机生成的16位aes密钥，通过rsa公钥加密
			String params = "";// 参数包体，通过paramsKey加密
			// 由apiKey paramsKey params 升序，生成paramsStr，
			// sign = MD5(apiKey+api+?+paramsStr)
			String sign = "";

			TreeMap<String, Object> paramsMap = new TreeMap<String, Object>();

			TreeMap<String, String> appMap = new TreeMap<String, String>();
			appMap.put("n", n);
			appMap.put("c", c);
			appMap.put("v", v);
			appMap.put("pk", pk);
			appMap.put("md5", md5);

			TreeMap<String, Object> dataMap = new TreeMap<String, Object>();
			dataMap.put("ot", ot);
			dataMap.put("os", 2);
			dataMap.put("accessCode", accessCode);
		
			paramsMap.put("app", appMap);// 应用信息
			paramsMap.put("data", dataMap);// 业务核心参数

			// 生成一个16位的随机aes密钥，对参数包体进行加密
			Gson gson = new Gson();
			//生成aeskey
			String aesKey = Uuid16.create() + "";
			//生成向量
			String ivStr =  Uuid16.create() + "";
			params = AESUtils.EncryptCbcIv(gson.toJson(paramsMap), aesKey,ivStr);
			//拼接aeskey
			aesKey = aesKey + ivStr;
			// 使用rsa公钥对aesKey进行加密
			PublicKey publicKey = RSAHelper.getPublicKey(pubKey);
			Cipher cipher = Cipher.getInstance("RSA");
			cipher.init(Cipher.ENCRYPT_MODE, publicKey);
			byte[] enBytes = cipher.doFinal(aesKey.getBytes());
			paramsKey = Base64.encode(enBytes);
			System.out.println("加密后的密文:" + paramsKey);

			// 创建签名sign
			String signTemp = apiKey + apiTemp + "?apiKey=" + apiKey + "&params=" + params + "&paramsKey=" + paramsKey;
			System.out.println("验签串：" + signTemp);
			sign = MD5.md5(signTemp);

			TreeMap<String, Object> p = new TreeMap<String, Object>();
			p.put("apiKey", apiKey);
			p.put("paramsKey", paramsKey);
			p.put("params", params);
			p.put("sign", sign);

			HttpClientUtil http = HttpClientUtil.getInstance();
			String result = http.getResponseBodyAsStringWithMap(url, p, "utf-8");
			System.out.println("【1】" + result);
			JSONObject json = new JSONObject(result);
			//查看code 0成功 1 失败
			System.out.println("【2】" + json.get("code"));
			//查看数据
			System.out.println("【3】" + json.get("obj"));
			JSONObject obj = new JSONObject(json.get("obj") + "");
			System.out.println("【4】" + obj.get("data"));
			String data = obj.get("data") + "";
			String aesKeyTemp = obj.get("aesKey") + "";
			cipher.init(Cipher.DECRYPT_MODE, publicKey);
			byte[] aaa = cipher.doFinal(Base64.decode(aesKeyTemp));
			String aesStrTemp = new String (aaa);
			String decrypt = AESUtils.DecryptCbcIv(data,aesStrTemp.substring(0, 16),aesStrTemp.substring( 16));
			System.out.println("解密后的明文：" + decrypt);
			return decrypt;
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}
	
}
