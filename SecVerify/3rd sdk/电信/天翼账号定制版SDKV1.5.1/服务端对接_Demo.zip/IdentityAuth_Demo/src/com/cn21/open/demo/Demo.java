package com.cn21.open.demo;

import com.alibaba.fastjson.JSONObject;
import com.cn21.open.demo.utils.Constants;
import com.cn21.open.demo.utils.HttpUtil;
import com.cn21.open.demo.utils.RequestUtil;
import com.cn21.open.demo.utils.cipher.AESUtil;
import com.cn21.open.demo.utils.cipher.RSAUtil;

import java.util.HashMap;
import java.util.Map;

/**
* @author: Chenzhenyong
* @description: 接口调用demo
* @date: Created in 9:18 2018/7/26
*/
public class Demo {

    private static final String GET_MOBILE_URL = "https://open.e.189.cn/openapi/networkauth/new/getMobile.do";

    public static void main(String[] args) throws Exception {

        //解密预取号返回的data，得到accessCode
        String data = "6F3D6E41E24103187B2FE76C4A488620090CDFD04D57E8BBB3364997758F2D06401B8923BEBC73C5EF18DBF6B38DADF35677EE8507B5923F2EE7C8A32028C4C10A4E68A8B61B8B816B72BF9069BC4CCDDDA9AEE863D9C15F76E47B66EA6696A3";
        String aesKey = "e1c3d0de067d4666";
        String decStr = AESUtil.decrypt(data, aesKey);
        System.out.println(decStr);
        JSONObject decStrObj = JSONObject.parseObject(decStr);
        String accessCode = decStrObj.getString("accessCode");

        String timeStamp = String.valueOf(System.currentTimeMillis());
        String format = "json";
        Map<String, String> generalParamsMap = new HashMap<>(0);
        Map<String, String> businessParamsMap = new HashMap<>(0);
        businessParamsMap.put("accessCode", accessCode);

        String params = RequestUtil.generateParams(businessParamsMap, Constants.APP_SECRET);
        generalParamsMap.put("clientId", Constants.APP_ID);
        generalParamsMap.put("timeStamp", timeStamp);
        generalParamsMap.put("format", format);
        generalParamsMap.put("params", params);
        String sign = RequestUtil.generateSign(generalParamsMap, Constants.PRI_KEY);
        generalParamsMap.put("sign", sign);

        StringBuffer sb = new StringBuffer();
        for(Map.Entry<String, String> entry : generalParamsMap.entrySet()){
            sb.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
        }
        System.out.println(GET_MOBILE_URL + "?" + sb.toString());

        String resp = HttpUtil.doHttpPost(GET_MOBILE_URL, generalParamsMap);
        System.out.println(resp);

        //取号结果需要RSA解密
        JSONObject respObj = JSONObject.parseObject(resp);
        if(0 == respObj.getInteger("result")) {
            String encData = respObj.getString("data");
            //使用RSA私钥解密encData
            String finalData = RSAUtil.decrypt(RSAUtil.loadPrivateKey(Constants.PRI_KEY), encData);
            System.out.println(finalData);
        }

        /*String getMobileData =
                "4BAFE870C6ADF71B620FF35FDBA634564C2E9FD47A36F064796C6A6BE1428CF3D75481763C244AEFD3295E104C6799B4AAE4E4D7A37D14265B29254C13CCEF336565B06E915940A6F48C37D9E81EF4507B65DEDF6EF3604A2F59C66BBF6392F1894617622AD1E0A776BA517B4BF6A3E2185A157E551BD750952167313132DD82";
        String finalData = RSAUtil.decrypt(RSAUtil.loadPrivateKey(Constants.PRI_KEY), getMobileData);
        System.out.println(finalData);*/
    }
}
