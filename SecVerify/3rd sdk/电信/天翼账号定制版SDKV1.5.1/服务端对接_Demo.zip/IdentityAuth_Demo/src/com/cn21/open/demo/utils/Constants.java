package com.cn21.open.demo.utils;

/**
* @author: Chenzhenyong
* @description: 常量工具类
* @date: Created in 12:25 2018/7/24
*/
public class Constants {

	/**
	 * 测试RSA公钥
	 */
	public static final String PUB_KEY = "";

	/**
	 * 测试RSA私钥
	 */
	public static final String PRI_KEY = "";
	/**
	 * 测试应用ID
	 */
	public static final String APP_ID = "";

	/**
	 * 测试应用秘钥(用于xxtea加密)
	 */
	public static final String APP_SECRET = "";

}
