package com.cn21.open.demo;

import com.alibaba.fastjson.JSONObject;
import com.cn21.open.demo.utils.Constants;
import com.cn21.open.demo.utils.HttpUtil;
import com.cn21.open.demo.utils.RequestUtil;
import com.cn21.open.demo.utils.cipher.RSAUtils;

import java.util.HashMap;
import java.util.Map;

/**
* @author: Chenzhenyong
* @description:
* @date: Created in 11:56 2018/8/29
*/
public class RefreshTokenDemo {

    private static final String REFRESH_TOKEN_URL = "https://open.e.189.cn/openapi/asymauth/access/refreshToken.do";

    public static void main(String[] args) throws Exception {
        System.out.println(Integer.MAX_VALUE);
        String timeStamp = String.valueOf(System.currentTimeMillis());
        String format = "json";
        Map<String, String> generalParamsMap = new HashMap<>(0);
        Map<String, String> businessParamsMap = new HashMap<>(0);
        String refreshToken = "c83901e7b04c49ff817effb0d7a29b25";
        businessParamsMap.put("refreshToken", refreshToken);

        String params = RequestUtil.generateParams(businessParamsMap, Constants.APP_SECRET);
        generalParamsMap.put("clientId", Constants.APP_ID);
        generalParamsMap.put("timeStamp", timeStamp);
        generalParamsMap.put("format", format);
        generalParamsMap.put("params", params);
        String sign = RequestUtil.generateSign(generalParamsMap, Constants.PRI_KEY);
        generalParamsMap.put("sign", sign);

        StringBuffer sb = new StringBuffer();
        for(Map.Entry<String, String> entry : generalParamsMap.entrySet()){
            sb.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
        }
        System.out.println(REFRESH_TOKEN_URL + "?" + sb.toString());

        String resp = HttpUtil.doHttpPost(REFRESH_TOKEN_URL, generalParamsMap);
        System.out.println(resp);

        //取号结果需要RSA解密
        JSONObject respObj = JSONObject.parseObject(resp);
        if(0 == respObj.getInteger("result")) {
            String encData = respObj.getString("data");
            //使用RSA私钥解密encData
            String finalData = RSAUtils.decryptByPrivateKeyForLongStr(encData, Constants.PRI_KEY);
            System.out.println(finalData);
        }
    }
}
